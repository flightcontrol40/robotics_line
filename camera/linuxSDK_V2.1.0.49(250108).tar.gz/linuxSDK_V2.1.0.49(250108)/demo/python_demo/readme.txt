﻿mvsdk.py:	相机SDK接口库（参考文档 WindowsSDK安装目录\Document\MVSDK_API_CHS.chm）

grab.py: 使用SDK采集图片，并保存到硬盘文件
cv_grab.py: 使用SDK采集图片，转换为opencv的图像格式
